package jdbc.join;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import jdbc.command.Board01;



public class JDBCSelect3 {

	public static void main(String[] args) {
		
		List<Board01> list = new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("조회 시작값");
		int start = sc.nextInt();
		
		System.out.print("조회 끝값");
		int end = sc.nextInt();
		
		//DB연결에 필요한 변수 	
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		String sql = "select  rn,\r\n" + 
				"         bno,\r\n" + 
				"         id,                 \r\n" + 
				"         title,\r\n" + 
				"         content\r\n" + 
				"		 from (select \r\n" + 
				"		                rownum rn,\r\n" + 
				"		                bno,\r\n" + 
				"		                id, \r\n" + 
				"		                title,\r\n" + 
				"		                content\r\n" + 
				"		        from (select\r\n" + 
				"		                        *\r\n" + 
				"		                from board01 \r\n" + 
				"		                order by bno desc))\r\n" + 
				"		 where rn >? and rn<=?	";
		
		//DB연동에 필요한 변수 	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try {
			
			// connector 안에 연결 드라이버를 호출
 			Class.forName("oracle.jdbc.driver.OracleDriver");
 			
 			// 커넥션 객체 생성
 			//커넥션객체 생성시에는 직접 new로 사용할 수 없고, 
 			//DriverManager 클래스가 제공하는 getter메서드를 통해서 생성
 			conn = DriverManager.getConnection(url,uid,upw);
 			
 			//SQL 쿼리문을 실행해주는 statement 객체를 생성
 			pstmt = conn.prepareStatement(sql);
 			
 			pstmt.setInt(1, start);
 			pstmt.setInt(2, end);
 			
 			//sql문 실행 - select문 - executeQuery(), 인서트, 딜리트, 업데이트 executeUpate()
 			rs = pstmt.executeQuery();
 			
 			//select 구문의 결과로 데이터가 존재하면 next()메서드는 true를 반환
 			//select 구문의 실행결과를 하나씩 처리할때, rs.getString(컬럼명) rs.getInt(컬럼명) rs.getTimeStamp(컬럼명)으로 사용
 			while(rs.next()) {
 				
 				int rn = rs.getInt("rn");
 				int bno = rs.getInt("bno");
 				String id = rs.getString("id");
 				String title = rs.getString("title");
 				String content = rs.getString("content");
 				
 				System.out.println(rn+" "+bno+" "+id+" "+title+" "+content);
 				
 				Board01 board = new Board01(rn,bno,id,title,content);
 				list.add(board);
 			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			sc.close();
 			try {
 				//null이 아니라면 클로즈 				
 				if(conn!=null) conn.close();
 				if(pstmt!=null) pstmt.close();
 				if(rs!=null) rs.close(); 				
 				
			} catch (Exception e2) {

			}
 		}
		
		list.forEach((b)-> System.out.println(b.getTitle()) );
		
//		for(int i=0; i<(end-start); i++)
//		System.out.println(list.get(i).getTitle());
		
	}
}
