package jdbc.book;

public interface Book_inter {

	
	public void bInsert(); //book 클래스 정보		
	public void bUpdate(); //book 클래스 정보	
	public void bDelete(); //book 클래스 정보
	
	
	
}
