package jdbc.book;

import java.util.Scanner;
import java.util.Map.Entry;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JDBCNeed {

	public static void main(String[] args) {	

		Scanner sc = new Scanner(System.in);


		//		Map<Member,List<Book>> map = new HashMap<>();

		/*
		 * 회원관리, 도서관리, 음악관리, 데이터 관리 등등 아무주제를 선택해서 JDBC프로그램을 작성합니다.
		 * 
		 * 단 테이블은 5개 이상 관계형 데이터 베이스 설계 
		 * 인터페이스를 반드시 사용합니다.
		 * ArrayList, Map중에 하나이상 반드시 사용합니다.
		 * 메서드는 8개 이상
		 */

		//회원과 도서관리자가 자신의 정보를 삽입수정삭제
		System.out.println("1.회원가입  2.회원 수정 3.회원 삭제");

		while(true) {

			System.out.println("-----메뉴 번호 선택-----");
			System.out.println("1.회원 정보메뉴 2. 도서 정보 메뉴 3.대여/반납메뉴 4.조회  5.종료");

			int menu = sc.nextInt();
			if(menu==5) break;

			if(menu==1) { //도서관리자가 도서에 대한 정보를 삽입수정삭제 
				System.out.println("-----회원 메뉴 번호 선택-----");
				System.out.println("1.회원 가입 2. 회원 정보 수정 3.회원 정보 삭제");
				int m_menu = sc.nextInt();

				Member m = new Member();

				switch (m_menu) {
				case 1:					
					m.mInsert();					
					break;

				case 2:					
					m.mUpdate();					
					break;
				case 3:
					m.mDelete();
					break;
				default:
					System.out.println("잘못 입력하셨습니다.");
					break;
				}
			} else if(menu==2) {
				System.out.println("-----도서 메뉴 번호 선택-----");
				System.out.println("1.정보 기입 2.정보 수정 3.정보 삭제");
				int b_menu = sc.nextInt();

				Book b = new Book();

				switch (b_menu) {
				case 1:	
					System.out.println("1.카테고리 기입 2.도서 기입");
					int b_menu1 = sc.nextInt();
					if(b_menu1==1)
						b.bcInsert();
					else if(b_menu1==2)
						b.bInsert();
					else 
						System.out.println("잘못입력하셨습니다.");
					break;

				case 2:			
					System.out.println("1.카테고리 수정 2.도서 수정");
					int b_menu2 = sc.nextInt();
					if(b_menu2==1)	
						b.bcUpdate();
					else if(b_menu2==2)
						b.bUpdate();
					else 
						System.out.println("잘못입력하셨습니다.");						
					break;

				case 3:
					System.out.println("1.카테고리 삭제 2.도서 삭제");
					int b_menu3 = sc.nextInt();
					if(b_menu3==1)	
						b.bcDelete();
					else if(b_menu3==2)
						b.bDelete();
					else 
						System.out.println("잘못입력하셨습니다.");						
					break;
				default:
					System.out.println("잘못 입력하셨습니다.");
					break;
				}
			} else if(menu==3) { //회원이 도서에 대해 대여, 반납
				Member m = new Member();

				System.out.println("1.도서 대여 2.도서 반납");
				int lr = sc.nextInt();

				if(lr==1)
					m.lend();
				else if(lr==2)
					m.re();
				else
					System.out.println("잘못 입력하셨습니다.");				
				
			} else if(menu==4) {//도서관리자가 회원의 정보를 검색 //회원이 도서정보를 검색
				
				Member m = new Member();

				System.out.println("1.회원조회 2.도서 조회");
				int search = sc.nextInt();

				if(search==1) {
					Set<Entry<Member, List<Book>>> entry = m.mSearch().entrySet();
					for(Entry<Member, List<Book>> me: entry) {

						System.out.println("-----회원정보-----");

						System.out.println(me.getKey().getId()+" "+
								me.getKey().getName()+" "+
								me.getKey().getEmail()+" "+
								me.getKey().getAddress()+" "+
								me.getKey().getGrade());
						System.out.println("-----빌린 책정보-----");
						me.getValue().forEach((l)-> System.out.println(
								l.getName()+" "+l.getCount()+" "+l.getLend_date()+" "+
										l.getRe_date()+" "+l.getPrice()
								));
					}
				}else if(search==2) {
					
					Book b = new Book();
					
					b = m.bSearch();

					System.out.println(b.getBook_num()+" "+b.getName()+" "+
							b.getPrice()+" "+b.getWriter()+" "+b.getCount());
				}
			}
		}

	}
}
