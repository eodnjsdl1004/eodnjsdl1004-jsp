package com.bean;

public class User {
	/*
	 * 자바빈 클래스는 form값과, 데이터베이스 의 통신과정에서 변수처리를 쉽게하기 위해서 사용하는 클래스
	 * 관련된 변수들을 선언, getter, setter를 반드시 생성합니다.
	 * 기본생성자를 반드시 생성합니다. 
	 */
	private String id;
	private String pw;
	private String name;
	private String email;
	
	//생성자는, 기본생성자와, 모든멤버변수를 초기화하는 생성자를 2개 선언합니다.
	public User() {
		
	}
	public User(String id, String pw, String name, String email) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
	}

	//alt + shift + s
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
}
