package com.myweb.user.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myweb.user.service.UserDeleteServiceImpl;
import com.myweb.user.service.UserGetInfoServiceImpl;
import com.myweb.user.service.UserJoinServiceImpl;
import com.myweb.user.service.UserServiceImpl;
import com.myweb.user.service.UserUpdateServiceImpl;
import com.myweb.user.service.UserloginServiceImpl;


@WebServlet("*.user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UserController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	protected void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		String path = request.getContextPath();
		String command = uri.substring(path.length());
		
		UserServiceImpl service = null;
		
		System.out.println(command);
		
		if(command.equals("/mvc2user/join.user")){
			
			request.getRequestDispatcher("user_join.jsp").forward(request, response);
		} else if(command.equals("/mvc2user/joinForm.user")) {
			
			service = new UserJoinServiceImpl();
			int result = service.execute(request, response);
			
			if(result==1) {
				
//				response.setContentType("text/html");
//				response.setCharacterEncoding("utf-8");
				response.setContentType("text/html; charset=utf-8");
				
				PrintWriter out = response.getWriter(); //out 객체 생성				
				out.println("<script>");
				out.println("alert(\"아이디가 중복되었습니다\")");
				out.println("location.href = \"user_join.jsp\"");
				out.println("</script>");
				
			} else if(result==2) {				
				response.sendRedirect("user_login.jsp");				
			} else {
				
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성				
				out.println("<script>");
				out.println("alert(\"회원가입 실패\")");
				out.println("location.href = \"user_join.jsp\"");
				out.println("</script>");				
			}
		} else if(command.equals("/mvc2user/login.user")) {			
			
			request.getRequestDispatcher("user_login.jsp").forward(request, response);			
		} else if(command.equals("/mvc2user/loginForm.user")) { // 로그인 요청
			/*
			 * UserloginServiceImpl() 생성후에 실행
			 * 서비스에서는 폼값을 받아서 DAO에 로그인 메서드를 사용해서 로그인 처리
			 * 로그인 성공하면 user_id이름으로 세션에 id를 저장하고 user_mypage로 리다이렉트
			 * 로그인 실패시 out.println을 이용해서 "아이디 비밀번호를 확인하세요" 문자열을 화면에 전송
			 */
			
			service = new UserloginServiceImpl();
			int result = service.execute(request, response);
			
			if(result ==1 ) {
				response.sendRedirect("mypage.user");
			}else {
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성
				
				out.println("<script>");
				out.println("alert(\"로그인 실패\")");
				out.println("history.go(-1)");
				out.println("</script>");
			}
		
		} else if(command.equals("/mvc2user/mypage.user")) {
			
			request.getRequestDispatcher("user_mypage.jsp").forward(request, response);
		} else if(command.equals("/mvc2user/modify.user")) {
			
			/*
			 * 게시판에 진입할 때 회원에 대한 모든 정보를 가져옵니다.
			 * GetInfoServiceImpl 서비스를 형성하고, DAO의 getInfo()메서드로 회원 아이디에 따른 회원정보를 얻어옵니다.
			 * 화면에서는 얻은 정보를 태그에 출력
			 */
			service = new UserGetInfoServiceImpl();
			int result = service.execute(request, response);
			
			if(result==0) {//값얻어오기 실패
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성
				
				out.println("<script>");
				out.println("alert('로그인 정보 얻기 실패')");
				out.println("history.go(-1)");
				out.println("</script>");
			} else {
				
				request.getRequestDispatcher("user_update.jsp").forward(request, response);
			}			
		} else if(command.equals("/mvc2user/updateForm.user")) {
			service = new UserUpdateServiceImpl();
			int result = service.execute(request, response);
			
			if(result==0) {
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성
				
				out.println("<script>");
				out.println("alert('현재 비밀번호와 일치하지 않습니다')");
				out.println("history.go(-1)");
				out.println("</script>");
			}else if(result == 1) {
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성
				
				out.println("<script>");
				out.println("alert('회원정보 수정 성공')");
				out.println("</script>");
				
				response.sendRedirect("mypage.user");
			}else {
				response.setContentType("text/html; charset=utf-8");				
				PrintWriter out = response.getWriter(); //out 객체 생성
				
				out.println("<script>");
				out.println("alert('회원정보 수정 실패')");
				out.println("</script>");
			}
		} else if(command.equals("/mvc2user/logout.user")) {
			HttpSession session = request.getSession();
			session.invalidate();
			response.sendRedirect("login.user");
		} else if(command.equals("/mvc2user/delete.user")) {
			
			request.getRequestDispatcher("user_delete.jsp").forward(request, response);
		} else if(command.equals("/mvc2user/deleteForm.user")) {
			
			/*
			 * DeleteServiceImpl에서 DAO의 login메서드를 실행해서 ID,PW 검증
			 * 검증된 유저라면 DAO의 delete 메서드를 실행해서 탈퇴를 진행
			 * delete메서드가 1을 반환하면 세션 삭제 후에 홈화면으로 이동
			 * delete메서드가 0을 반환하면 "회원 비밀번호를 확인하세요" 메세지를 화면에 출력하고,
			 * 탈퇴화면으로 이동 
			 */
			
			service = new UserDeleteServiceImpl();
			int result = service.execute(request, response);
			
			if(result == 2) {
				response.setContentType("text/html; charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('회원비밀번호를 확인하세요')");
				out.println("location.href='delete.user'");
				out.println("</script>");				
			} else if(result==1) {
				HttpSession session = request.getSession();
				session.invalidate();
				
				response.setContentType("text/html; charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('회원정보 삭제')");				
				out.println("</script>");
				response.sendRedirect(request.getContextPath()+"/main.do");/*login.user*/
			} else {
				response.setContentType("text/html; charset=utf-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('회원정보 삭제 실패')");
				out.println("location.href='delete.user'");
				out.println("</script>");
			}
			
		}
		
	}

}
