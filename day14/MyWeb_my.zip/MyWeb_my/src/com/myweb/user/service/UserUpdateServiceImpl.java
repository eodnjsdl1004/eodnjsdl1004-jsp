package com.myweb.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myweb.user.model.UserDAO;
import com.myweb.user.model.UserVO;

public class UserUpdateServiceImpl implements UserServiceImpl{

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");		
		String old_pw = request.getParameter("old_pw"); 
		String new_pw = request.getParameter("new_pw");	
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		
		System.out.println("이전:"+old_pw);
		System.out.println(new_pw);
		UserDAO dao = UserDAO.getInstance();
		int result = dao.login(id, old_pw);
		System.out.println(result);
		if(result == 1 ) {
			UserVO vo = new UserVO(id,new_pw,name,email,address,null);
			
			int result2 = dao.update(vo);			
			if(result2 == 1) { //비밀번호 및 회원정보 변경 성공
				return 1;				
			}else {	//비밀번호 및 회원정보 변경 실패
				return 2;
			}
		}else {//현재비밀번호가 맞지않음			
			return 0;
		}
		
	}

}
