package com.myweb.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myweb.user.model.UserDAO;
import com.myweb.user.model.UserVO;

public class UserJoinServiceImpl implements UserServiceImpl{

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		
		//DAO객체생성
		UserDAO dao = UserDAO.getInstance();	
		UserVO vo = new UserVO(id, pw, name, email, address, null);
		int result = dao.checkId(id);
		
		if(result ==1 ) { //아이디 이미 존재

			return result;
		} else {
		   int rs = dao.join(vo);
		   if(rs ==1) {
			   return 2;
		   } else {
			   return 0;
		   }
		}		
	}

}
