package com.jdbc.model;

public class MainClass {

	public static void main(String[] args) {
		MemberDAO dao = MemberDAO.getInstance();
		
		System.out.println(dao);
	}
}
