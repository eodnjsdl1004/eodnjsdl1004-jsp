package com.ok;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jdbc.model.MemberDAO;
import com.jdbc.model.MemberVO;

@WebServlet("/Modify_ok")
public class Modify_ok extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Modify_ok() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//정보수정페이지로 이동하기 위해 DB에서 정보를 가져오는 작업.
		
		//아이디는 세션에서 얻음
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("user_id");
		
		
		//DAO생성
		MemberDAO dao = MemberDAO.getInstance();
		//getInfo() 실행 결과로 VO를 받습니다.
		MemberVO vo = dao.getInfo(id);
		
		//vo를 request에 통째로 강제 저장하고, 포워드 이동
		request.setAttribute("vo", vo);
		
		RequestDispatcher dp  = request.getRequestDispatcher("update.jsp");
		dp.forward(request, response);
		
		
		
		
		/*
		//DB연동에 필요한 변수를 선언
		String url = "jdbc:mysql://localhost:3306/test?serverTimezone=Asia/Seoul";
		String uid = "jsp";
		String upw = "jsp";
		
		Connection conn = null; //java.sql패키지
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select * from user where id = ?";
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			conn = DriverManager.getConnection(url, uid, upw); //커넥션객체
			
			pstmt = conn.prepareStatement(sql); //sql문 전송객체
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			
//			 rs.next()를 통해서 다음행의 조회를 합니다.
//			 rs.getString(컬럼명) 을 이용해서 
//			 name, phone1, phone2, gender컬럼값을 얻습니다
//			 
//			 request에 강제 저장후에 포워드 이동으로 update.jsp로 
			 

			if(rs.next()) {
				String name = rs.getString("name");
				String phone1 = rs.getString("phone1");
				String phone2 = rs.getString("phone2");
				String gender = rs.getString("gender");
				//request에 강제저장
				request.setAttribute("user_name", name);
				request.setAttribute("user_phone1", phone1);
				request.setAttribute("user_phone2", phone2);
				request.setAttribute("user_gender", gender);
				//포워드 이동
				RequestDispatcher dp = request.getRequestDispatcher("update.jsp");
				dp.forward(request, response);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				
			}
		}
		*/
		
		
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
