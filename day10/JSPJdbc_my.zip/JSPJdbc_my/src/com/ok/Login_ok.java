package com.ok;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jdbc.model.MemberDAO;

@WebServlet("/Login_ok")
public class Login_ok extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Login_ok() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//폼데이터 처리
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		/*
		 * 1. MemberDAO 객체 생성
		 * 2. dao에 login(id, pw) 메서드를 생성하고 실행
		 * 3. login메서드 안에서 executeQuery() 구문으로 실행하고 rs.next() 결과가 있다면 1을 반환
		 * 	  결과가 없다면 0을 반환
		 * 
		 * 4. Login_ok에서는 세션에 id를 저장하고 화면으로 이동
		 */
		
		//DAO객체생성
		MemberDAO dao = MemberDAO.getInstance();
		
		int result = dao.login(id, pw);

		
		if( result == 1) { //성공인경우			
			
			HttpSession session = request.getSession();
			session.setAttribute("id", id);
			
			response.sendRedirect("join_login/login_welcome.jsp");
			
		} else { //실패인경우
			response.sendRedirect(request.getContextPath()+"/join_login/login_fail.jsp");
		}
		
		/*
		//DB연동에 필요한 변수를 선언
		String url = "jdbc:mysql://localhost:3306/test?serverTimezone=Asia/Seoul";
		String uid = "jsp";
		String upw = "jsp";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select * from user where id = ? and pw = ?"; 
		
		try {
			//드라이버 로드
			Class.forName("com.mysql.cj.jdbc.Driver");
			//커넥션 생성
			conn = DriverManager.getConnection(url, uid, upw);
			//pstmt 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rs = pstmt.executeQuery(); //select구문만 Query()메서드를 사용
			
			if(rs.next() ) { //아이디와 PW가 일치하는 경우
				
				//자바에서 세션 사용방법
				HttpSession session = request.getSession();
				session.setAttribute("user_id", id);
				
				response.sendRedirect("mypage.jsp");
			} else { //아이디 PW가 틀린 경우
				response.sendRedirect("login_fail.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if( conn != null) conn.close();
				if( pstmt != null) pstmt.close();
				if( rs != null) rs.close();
			} catch (Exception e2) {
				
			}
		}
		*/
		
		
	}

}
