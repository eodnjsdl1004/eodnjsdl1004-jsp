package com.ok;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jdbc.model.MemberDAO;


@WebServlet("/Delete_ok")
public class Delete_ok extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Delete_ok() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*
		 * delete from 테이블명 where id = ?
		 * 
		 * 1. 아이디는 세션에서 얻습니다. DAO에 delete(id) 메서드를 생성
		 * 2. pstmt를 이용해서 삭제를 진행
		 * 3. executeUpdate() 메서드를 통해서 sql문을 실행하고
		 *    1을반환하면 세션을 전부다 삭제후에 login.jsp로 이동
		 *    0을반환하면 mypage.jsp로 이동
		 * 
		 */
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");

		MemberDAO dao = MemberDAO.getInstance();
		
		int result = dao.delete(id);
		
		if(result == 1) { //삭제 성공
			
			session.invalidate();
			response.sendRedirect("join_login/login.jsp");
			
		} else {
			response.sendRedirect("join_login/login_welcome.jsp");
		}
		
		
		
		
		/*
		//DB연동에 필요한 변수를 선언
		String url = "jdbc:mysql://localhost:3306/test?serverTimezone=Asia/Seoul";
		String uid = "jsp";
		String upw = "jsp";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		String sql = "delete from user where id = ?";
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			conn = DriverManager.getConnection(url, uid, upw);
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, id);
			
			int result = pstmt.executeUpdate();
			
			if(result == 1) { //삭제성공
				session.invalidate(); //세션삭제
				response.sendRedirect("login.jsp");
			} else {
				response.sendRedirect("mypage.jsp");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			} catch (Exception e2) {
				
			}
		}
		
		*/
		
		
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
