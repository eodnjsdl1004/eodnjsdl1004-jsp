package com.ok;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.model.MemberDAO;
import com.jdbc.model.MemberVO;

@WebServlet("/Update_ok")
public class Update_ok extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Update_ok() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//폼데이터 처리
		request.setCharacterEncoding("utf-8"); //한글처리
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String phone1 = request.getParameter("phone1");
		String phone2 = request.getParameter("phone2");
		String phone3 = request.getParameter("phone3");
		String gender = request.getParameter("gender");
		
		/*
		 * 1. 폼데이터값들을 VO에 저장
		 * 2. DAO객체를 생성하고 update메서드로 vo를 전달합니다.
		 * 3. update메서드안에서는 executeUpdate() 메서드로 실행
		 *    1을반환 하면 update_success.jsp로 이동
		 *    0을반환 하면 mypage.jsp
		 */
		//DAO객체 생성
		MemberDAO dao = MemberDAO.getInstance();
		//VO객체 생성
		MemberVO vo = new MemberVO(id, pw, name, phone1, phone2,phone3, gender);
		
		int result = dao.update(vo);
		
		if(result == 1) { //성공
			response.sendRedirect("join_login/update_success.jsp");
		} else { //실패
			response.sendRedirect("join_login/update_fail.jsp");
		}
		/*
		//DB연동에 필요한 변수를 선언
		String url = "jdbc:mysql://localhost:3306/test?serverTimezone=Asia/Seoul";
		String uid = "jsp";
		String upw = "jsp";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		String sql = "update user set pw = ?, name = ?, phone1 = ?, phone2 = ?, gender = ? where id = ?";
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver"); //드라이버호출
			
			conn = DriverManager.getConnection(url, uid, upw); //커넥션생성
			
			pstmt = conn.prepareStatement(sql); //pstmt 생성
			pstmt.setString(1, pw);
			pstmt.setString(2, name);
			pstmt.setString(3, phone1);
			pstmt.setString(4, phone2);
			pstmt.setString(5, gender);
			pstmt.setString(6, id);
			
			int result = pstmt.executeUpdate(); //sql문 실행
			
			if(result == 1) {
				response.sendRedirect("update_success.jsp"); //성공시 성공페이지로
			} else {
				response.sendRedirect("mypage.jsp"); //실패시 마이페이지로 
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			} catch (Exception e2) {
				
			}
			
		}
		*/
		
	}

}
