package com.ok;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.model.MemberDAO;
import com.jdbc.model.MemberVO;


@WebServlet("/Join_ok")
public class Join_ok extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Join_ok() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//폼데이터 처리
		request.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String phone1 = request.getParameter("phone1");
		String phone2 = request.getParameter("phone2");
		String phone3 = request.getParameter("phone3");
		String gender = request.getParameter("gender");
		
		//DAO객체 생성
		MemberDAO dao = MemberDAO.getInstance();
		
		//VO객체 생성
		MemberVO vo = new MemberVO(id, pw, name, phone1, phone2,phone3, gender);
		
		int result = dao.join(vo);
		
		if(result == 1) { //성공
			response.sendRedirect(request.getContextPath()+"/join_login/join_result.jsp");
		} else { //실패
			response.sendRedirect("join_login/join_fail.jsp");
		}
		
		/*
		//DB연동에 필요한 변수를 선언
		String url = "jdbc:mysql://localhost:3306/test?serverTimezone=Asia/Seoul";
		String uid = "jsp";
		String upw = "jsp";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		//String sql = "insert into user values('"+id+"', '"+pw+"', '"+name+"', '"+phone1+"', '"+phone2+"', '"+gender+"' )";
		String sql = "insert into user values(?,?,?,?,?,?)";
		
		try {
			//드라이버 호출
			Class.forName("com.mysql.cj.jdbc.Driver");
			//커넥션생성
			conn = DriverManager.getConnection(url, uid, upw);
			//sql문 전송객체
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, name);
			pstmt.setString(4, phone1);
			pstmt.setString(5, phone2);
			pstmt.setString(6, gender);
					
			//결과 실행
			int result = pstmt.executeUpdate();
			
			if(result == 1) { //성공시 성공화면으로 이동
				response.sendRedirect("join_success.jsp");
			} else { //실패시 실패화면 이동
				response.sendRedirect("join_fail.jsp");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn != null) conn.close();
				if(pstmt != null) pstmt.close();
			} catch (Exception e2) {
				
			}
		}
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
