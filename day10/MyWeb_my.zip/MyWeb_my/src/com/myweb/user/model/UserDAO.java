package com.myweb.user.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.myweb.util.JdbcUtil;

public class UserDAO {


	//1. 스스로의 객체를 멤버변수로 선언하고 1개로 제한
		private static UserDAO instance = new UserDAO();
		
		//2. 외부에서 객체를 생성할 수 없도록 생성자에 private
		private UserDAO() {
			//커넥션풀을 꺼내는 작업
			try {
				InitialContext ctx = new InitialContext(); //초기 설정파일 저장되는 객체
				ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
//				Class.forName("oracle.jdbc.driver.OracleDriver");
				
			} catch (NamingException e) {
				System.out.println("커넥션 풀링 에러 발생");
			}
			
		}
		//3. 외부에서 객체를 요구할때 getter메서드만 써서 반환
		public static UserDAO getInstance() {
			return instance;
		}
		
		//-----------중복되는 코드는 멤버변수로 선언-----------
//		private String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
//		private String uid = "JSP";
//		private String upw = "jsp";
		
		private DataSource ds;
		
		private Connection conn = null;
		private PreparedStatement pstmt = null;
		private ResultSet rs = null;
		
		
		//아이디 중복검사
		public int checkId(String id) {
			
			int result = 0;
			
			String sql = "select * from users where id = ?";
			
			try {
				
				conn = ds.getConnection(); //멤버변수 DataSource에서 커넥션풀을 얻어옴
//				System.out.println(conn);
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);				
				
				rs = pstmt.executeQuery();
				
				if(rs.next() ) { //결과가 있다는 것은 중복의 의미
					return 1; //중복시 1반환
				} else {
					return 0; //중복되지 않은 경우 0을반환
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt, rs);
			}
			return result;
		}
		
}
