package com.myweb.user.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

//import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.myweb.util.JdbcUtil;

public class UserDAO {


	//1. 스스로의 객체를 멤버변수로 선언하고 1개로 제한
		private static UserDAO instance = new UserDAO();
		
		//2. 외부에서 객체를 생성할 수 없도록 생성자에 private
		private UserDAO() {
			//커넥션풀을 꺼내는 작업
			try {
				InitialContext ctx = new InitialContext(); //초기 설정파일 저장되는 객체
				ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
//				Class.forName("oracle.jdbc.driver.OracleDriver");
				
			} catch (NamingException e) {
				System.out.println("커넥션 풀링 에러 발생");
			}
			
		}
		//3. 외부에서 객체를 요구할때 getter메서드만 써서 반환
		public static UserDAO getInstance() {
			return instance;
		}
		
		//-----------중복되는 코드는 멤버변수로 선언-----------
//		private String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
//		private String uid = "JSP";
//		private String upw = "jsp";
		
		private DataSource ds;
		
		private Connection conn = null;
		private PreparedStatement pstmt = null;
		private ResultSet rs = null;
		
		
		//아이디 중복검사
		public int checkId(String id) {
			
			int result = 0;
			
			String sql = "select * from users where id = ?";
			
			try {
				
				conn = ds.getConnection(); //멤버변수 DataSource에서 커넥션풀을 얻어옴
//				System.out.println(conn);
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);				
				
				rs = pstmt.executeQuery();
				
				if(rs.next() ) { //결과가 있다는 것은 중복의 의미
					return 1; //중복시 1반환
				} else {
					return 0; //중복되지 않은 경우 0을반환
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt, rs);
			}
			return result;
		}
		
		public int join(UserVO vo) {
			int result = 0;
			
			String sql = "insert into users(id, pw, name, email, address) values(?, ?, ?, ?, ?)";
			//regdate는 디폴트값 사용
			try {
				conn = ds.getConnection();
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, vo.getId() );
				pstmt.setString(2, vo.getPw() );
				pstmt.setString(3, vo.getName() );
				pstmt.setString(4, vo.getEmail() );
				pstmt.setString(5, vo.getAddress() );
				
				result = pstmt.executeUpdate(); //성공시 1, 실패시 0
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt);
			}
			
			
			return result;
		}
		
		public int login(String id, String pw) {
			int result=0;
			
			String sql = "select * from users where id=? and pw=?";
			
			try {
				conn=ds.getConnection();
				
				pstmt=conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, pw);				
				
				rs=pstmt.executeQuery();
				
				if(rs.next()) {
					result=1;
				} else {
					result=0;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt, rs);
			}			
			return result;
		}
		
		
		public UserVO getUserInfo(String id) {
			UserVO vo = null;
			
			String sql = "select * from users where id = ?";
			
			try {
				
				conn = ds.getConnection();
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					//DB에서 getString(컬럼명), getTimeStamp(컬럼명) 메서드를 이용해서
					//rs의 데이터 결과를 vo에 저장하는 코드.
					
					
					String name = rs.getString("name");
					String email = rs.getString("email");
					String address =rs.getString("address");
					Timestamp regdate = rs.getTimestamp("regdate"); //시간타입을 얻음
					
					vo = new UserVO(id, null, name, email, address, regdate);					
				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt, rs);
			}			
			
			return vo;
		}
		
		public int update(UserVO vo) {
			int result=0;
			
			String sql = "update users set name=?, email =?, address=? where id=?";
			
			try {
				
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, vo.getName());
				pstmt.setString(2, vo.getEmail());
				pstmt.setString(3, vo.getAddress());
				
				pstmt.setString(4, vo.getId());
				
				result= pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt);
			}	
			
			return result;
		}
		
		public int delete(String id) {
			int result=0;
			
			String sql ="delete from users where id=?";
			
			
			try {
				conn = ds.getConnection();
				
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, id);
				
				result = pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt);
			}
			
			return result;
		}
		
		
		public int changePassword(String id, String new_pw) {
			
			int result = 0;
			
			String sql ="update users set pw = ? where id = ?";
			
			try {
				conn = ds.getConnection();
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, new_pw);
				pstmt.setString(2, id);
				
				result = pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JdbcUtil.close(conn, pstmt);
			}
			return result;
		}
	
		
}
