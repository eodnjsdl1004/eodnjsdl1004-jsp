package com.myweb.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//어노테이션을 확장자 패턴으로 변경(*.test로 끝나는 요청을 다 받음)
@WebServlet("*.test")
public class TestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public TestController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println(request.getRequestURI());
		doAction(request, response);		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	//get요청과 post 요청을 하나로 묶어줍니다.
	protected void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//요청분기(uri기반으로)
		String uri = request.getRequestURI();
		String path = request.getContextPath();
		
		String command = uri.substring( path.length() );
		
		System.out.println(command);
		
		if(command.equals("/controller/join.test")) {
			//로그인 처리...
		}
		
		
		
	}

}
