package com.myweb.board.service;

//import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myweb.board.model.BoardDAO;
import com.myweb.board.model.BoardVO;

public class GetListServiceImpl implements IBoardService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		//DAO객체 생성
		BoardDAO dao = BoardDAO.getInstance();
		
		//DB에서 모든 글목록을 조회해서 VO에 담고, VO를 list에 추가
		List<BoardVO> list = dao.getList(); //목록조회 결과를 list형태로 받음
		
		//다음 화면에서 사용하기 위해서 request객체에 강제 저장
		request.setAttribute("boardList", list);
		
	}

	
}
