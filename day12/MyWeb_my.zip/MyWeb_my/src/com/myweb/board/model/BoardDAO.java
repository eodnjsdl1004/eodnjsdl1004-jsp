package com.myweb.board.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.myweb.util.JdbcUtil;

public class BoardDAO {
	//1. 스스로의 객체를 멤버변수로 선언하고 1개로 제한
	private static BoardDAO instance = new BoardDAO();
	
	//2. 외부에서 객체를 생성할 수 없도록 생성자에 private
	private BoardDAO() {
		//커넥션풀을 꺼내는 작업
		try {
			InitialContext ctx = new InitialContext(); //초기 설정파일 저장되는 객체
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
			
		} catch (NamingException e) {
			System.out.println("커넥션 풀링 에러 발생");
		}
		
	}
	//3. 외부에서 객체를 요구할때 getter메서드만 써서 반환
	public static BoardDAO getInstance() {
		return instance;
	}
	
	//-----------중복되는 코드는 멤버변수로 선언-----------
	
	private DataSource ds;
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	
	//글 등록 메서드
	public void regist(String writer, String title, String content) {
		
		String sql = "insert into board(bno,writer, title, content) values(bno_seq.nextval,?,?,? )";
	
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, writer);
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
	}
	
	//게시물 목록 조회 메서드
	public ArrayList<BoardVO> getList() {
		
		ArrayList<BoardVO> list = new ArrayList<>();
		
		String sql = "select * from board order by bno desc";
		
		try {
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while( rs.next() ) {
				//rs.getString(컬럼명), rs.getInt(컬럼명), rs.getTimestamp(컬럼명)
				//데이터를 vo에 담고, vo를 list에 저장하는 코드 작성
				
				int bno = rs.getInt("bno");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Timestamp regdate = rs.getTimestamp("regdate");
				int hit = rs.getInt("hit");
				
				BoardVO vo = new BoardVO(bno, writer, title, content, regdate, hit);
				
				list.add(vo); //리스트에 추가				
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		return list;
	}
	
	//상세보기 처리 메서드
	public BoardVO getContent(int bno) {
		
		BoardVO vo = null;
		
		String sql = "select * from board where bno = ?";
		
		try {
			
			conn = ds.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			
			rs = pstmt.executeQuery();
			
			if(rs.next() ) { //다음행에 대한 조회
				
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Timestamp regdate = rs.getTimestamp("regdate");
				int hit = rs.getInt("hit");
				
				vo = new BoardVO(bno, writer, title, content, regdate, hit);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}		
		return vo;
	}
	
	//수정 처리 메서드
	public void update(String bno, String title, String content) {
		
		String sql = "update board set title =?, content =? where bno = ?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title );
			pstmt.setString(2, content);
			pstmt.setString(3, bno);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
	}
	
	//삭제 메서드 실행
	public void delete(String bno) {
		
		String sql = "delete from board where bno = ?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bno);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, pstmt, rs);
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
