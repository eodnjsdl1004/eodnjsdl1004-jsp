package com.myweb.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myweb.board.service.ContentServiceImpl;
import com.myweb.board.service.DeleteServiceImpl;
import com.myweb.board.service.GetListServiceImpl;
import com.myweb.board.service.IBoardService;
import com.myweb.board.service.RegistServiceImpl;
import com.myweb.board.service.UpdateServiceImpl;

//확장자패턴으로 맵핑을 변경
@WebServlet("*.board")
public class BoardController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    public BoardController() {
        super();
      }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	//get,post방식을 하나로 묶는다
	protected void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		String uri = request.getRequestURI();
		String path = request.getContextPath();
		
		String command = uri.substring(path.length());
		System.out.println(command);
		
		IBoardService service = null;
		
		if(command.equals("/board/list.board")) { //게시글 화면 요청
			
			//게시글 목록 정보를 가지고 화면으로 이동하도록 처리
			service = new GetListServiceImpl();
			service.execute(request, response);
			
			//response.sendRedirect("board_list.jsp");			
			request.getRequestDispatcher("board_list.jsp").forward(request, response);
			
		} else if(command.equals("/board/write.board")) { //글 등록 화면 요청
			request.getRequestDispatcher("board_write.jsp").forward(request, response);
			
		} else if(command.equals("/board/regist.board")) {
			
			service = new RegistServiceImpl();			
			service.execute(request, response);
			
			
			response.sendRedirect("list.board"); //다시 컨트롤러를 태워준다.
//			request.getRequestDispatcher("/board/list.board").forward(request, response); // 새로고침하면 계속 생성됨
			
		} else if(command.equals("/board/content.board")) { //상세보기화면 요청
			
			service = new ContentServiceImpl();
			service.execute(request, response);
			
			request.getRequestDispatcher("board_content.jsp").forward(request, response);
			
		} else if(command.equals("/board/modify.board")) { //수정 화면 실행
			/*
			 * 화면에서 경로에 bno 값을 전달합니다.
			 * UpdateServiceImpl()을 전달합니다.
			 * 포워드로 board_modify.jsp로 이동
			 * 화면에서는 태그란에 데이터값을 출력 
			 */
			service = new ContentServiceImpl();
			service.execute(request, response);
			
			request.getRequestDispatcher("board_modify.jsp").forward(request, response);
		} else if(command.equals("/board/update.board")) { //수정처리 요청
			
			/*
			 * 1. UpdateServiceImpl을 생성합니다.
			 * 2. 서비스 영역에서는 bno, title, content울 받아서 update() 메서드를 실행
			 * 3. DAO의 update() 에서는 update구문으로 데이터를 수정
			 * 4. 페이지 이동을 상세화면으로 연결 (단, 필요한 값을 전달해야 함)
			 * 
			 * sql = "update board set title =?, content =? where bno = ?"
			 * 
			 */
			
			service = new UpdateServiceImpl();
			service.execute(request, response);			
			
			
			String bno = request.getParameter("bno");
			//다시 컨트롤러에 태울때 redirect로 보냄
			response.sendRedirect("content.board?bno="+ bno); //content.board는 bno값을 반드시 필요로 함.
		} else if(command.equals("/board/delete.board")) {
			/*
			 * 1. DeleteServiceImpl을 생성합니다
			 * 2. 서비스 영역에서는bno를 받아서 delete()메서드 실행
			 * 3. DAO의 delete()에서는 delete구문으로 삭제 
			 * 4. 페이지 이동을 목록으로
			 * 
			 * sql = "delete from board where bno = ?"
			 */
			
			service = new DeleteServiceImpl();
			service.execute(request, response);
			
			response.sendRedirect("list.board");
		}
		
	}

}
