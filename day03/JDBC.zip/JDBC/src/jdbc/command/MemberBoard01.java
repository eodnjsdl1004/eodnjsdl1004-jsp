package jdbc.command;

import java.util.ArrayList;
import java.util.List;

public class MemberBoard01 {

	//주테이블의 컬럼을 멤버변수, 부테이블의 컬럼을 List로 표현
	private String id;
	private String pw;
	private String name;
	private String email;
	private String address;	
	
	//join해서 붙을 테이블의 클래스를 리스트 멤버변수로 선언
	private List<Board01> list = new ArrayList<Board01>(); 
	
	public MemberBoard01() {
		
	}

	public MemberBoard01(String id, String pw, String name, String email, String address/*, List<Board01> list*/) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.address = address;
		//this.list = list;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Board01> getList() {
		return list;
	}

	public void setList(List<Board01> list) {
		this.list = list;
	}
	
	
}
