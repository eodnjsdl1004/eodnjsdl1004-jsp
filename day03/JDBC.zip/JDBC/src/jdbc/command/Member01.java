package jdbc.command;

public class Member01 {

	private String id;
	private String pw;
	private String name;
	private String address;
	private String email;
	
	public Member01() {
		
	}
	
	public Member01(String id, String pw, String name, String address, String email) {
		
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.address = address;
		this.email = email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
