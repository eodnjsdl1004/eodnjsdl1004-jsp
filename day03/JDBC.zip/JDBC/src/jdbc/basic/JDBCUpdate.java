package jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class JDBCUpdate {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("수정할 아이디 입력>");
		String id = sc.next();
		
		System.out.print("수정할 이름 입력>");
		String name = sc.next();
		
		System.out.print("수정할 이메일 입력>");
		String email = sc.next();
		
		System.out.print("수정할 주소 입력>");
		String address = sc.next();
		
		//DB연동에 필요한 변수
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		//pk는 수정 안함.
		String sql = "Update member01 set name =?, email =?, address =? where id = ?";
				
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//연결객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송객체 생성
			pstmt = conn.prepareStatement(sql);
			
			//?값 저장
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			pstmt.setString(3, address);
			pstmt.setString(4, id);
			
			int rs = pstmt.executeUpdate(); // 성공시 1반환
			
			if(rs == 1) {
				System.out.println(id+"회원 DB수정 성공");
			}else {
				System.out.println(id+"회원 DB수정 실패");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
			try {
				if(conn!= null) conn.close();
				if(pstmt!= null) pstmt.close();
				
			} catch (Exception e2) {
				
			}
		}
		
	}
}
