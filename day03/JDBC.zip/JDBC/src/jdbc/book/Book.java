package jdbc.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Book implements Book_inter{

	private String book_num; // cno+bno

	private String name;
	private int price;
	private String writer;
	private int count;	

	private String day;
	private int bCount;
	private String lend_date;
	private String re_date;

	Scanner sc = new Scanner(System.in);

	public Book() {

	}


	public Book(String book_num, String name, int price, String writer, int count) {
		super();
		this.book_num = book_num;
		this.name = name;
		this.price = price;
		this.writer = writer;
		this.count = count;
	}

	public String getBook_num() {
		return book_num;
	}

	public void setBook_num(String book_num) {
		this.book_num = book_num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}	

	public String getLend_date() {
		return lend_date;
	}

	public void setLend_date(String lend_date) {
		this.lend_date = lend_date;
	}

	public String getRe_date() {
		return re_date;
	}


	public void setRe_date(String re_date) {
		this.re_date = re_date;
	}	

	public String getDay() {
		return day;
	}


	public void setDay(String day) {
		this.day = day;
	}


	public int getbCount() {
		return bCount;
	}


	public void setbCount(int bCount) {
		this.bCount = bCount;
	}


	@Override
	public void bInsert() {

		System.out.print("분야>");
		String field = sc.next();

		System.out.print("유형>");
		String type = sc.next();

		System.out.print("책이름>");
		String name = sc.next();

		System.out.print("가격>");
		int price = sc.nextInt();

		System.out.print("글쓴이>");
		String writer = sc.next();

		System.out.print("수량>");
		int count = sc.nextInt();




		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into Book values(SEQ_book_bno.nextval,"
				+ "(select cno from category where field = ? and type = ? ) ,?,?,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, field);
			pstmt.setString(2, type);

			pstmt.setString(3, name);
			pstmt.setInt(4, price);
			pstmt.setString(5, writer);
			pstmt.setInt(6, count);

			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("DB입력 성공");
			}else {
				System.out.println("아이디 중복");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		

	}

	@Override
	public void bUpdate() {

		System.out.print("바꿀 책이름>");
		String search = sc.next();


		System.out.print("수정 이름>");
		String name = sc.next();

		System.out.print("수정 가격>");
		int price = sc.nextInt();

		System.out.print("수정 글쓴이>");
		String writer = sc.next();

		System.out.print("수정 수량>");
		int count = sc.nextInt();

		//DB연동에 필요한 변수
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//pk는 수정 안함.
		String sql = "Update book set name =?, price =?, writer =?, count=? where name = ?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setString(1, name);
			pstmt.setInt(2, price);
			pstmt.setString(3, writer);
			pstmt.setInt(4, count);
			pstmt.setString(5, search);

			int rs = pstmt.executeUpdate(); // 성공시 1반환

			if(rs == 1) {
				System.out.println(search+"책 DB수정 성공");
			}else {
				System.out.println(search+"는 없는 책입니다.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!= null) conn.close();
				if(pstmt!= null) pstmt.close();

			} catch (Exception e2) {

			}
		}


	}

	@Override
	public void bDelete() {

		System.out.print("삭제할 책 입력>");
		String name = sc.next();

		//DB 연결 변수 
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//sql문
		String sql = "delete from book where name = ?";

		//DB 연동		
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {			
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);

			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setString(1, name);			

			//전송결과 저장
			int rs = pstmt.executeUpdate();

			if(rs == 1) {
				System.out.println(name+"책 정보 삭제 성공");
			} else {
				System.out.println(name+"는 없는 책입니다.");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e2) {

			}
		}
	}

	public void bcInsert() {		


		System.out.print("분야>");
		String field = sc.next();

		System.out.print("유형>");
		String type = sc.next();

		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into category values(SEQ_category_cno.nextval,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1,field);
			pstmt.setString(2,type);

			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("카테고리 DB입력 성공");
			}else {
				System.out.println("카테고리 DB입력 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		
	}

	public String bcUpdate() {		

		System.out.print("수정 카테고리 번호>");
		int cno = sc.nextInt();

		System.out.print("수정 분야>");
		String field = sc.next();

		System.out.print("수정 유형>");
		String type = sc.next();


		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "Update category set field =?, type =? where cno = ?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1,field);
			pstmt.setString(2,type);
			pstmt.setInt(3,cno);

			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("카테고리 DB수정 성공");
			}else {
				System.out.println(cno+"번 DB수정 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		

		return name;
	}

	public void bcDelete() {

		System.out.print("삭제할 카테고리번호 입력>");
		int cno = sc.nextInt();

		//DB 연결 변수 
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//sql문
		String sql = "delete from category where cno = ?";

		//DB 연동		
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {			
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);

			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setInt(1, cno);			

			//전송결과 저장
			int rs = pstmt.executeUpdate();

			if(rs == 1) {
				System.out.println(cno+"카테고리 정보 삭제 성공");
			} else {
				System.out.println(cno+"는 없는 카테고리입니다.");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e2) {

			}
		}
	}




}

