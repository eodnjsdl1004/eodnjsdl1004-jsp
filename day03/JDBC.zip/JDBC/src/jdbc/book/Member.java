package jdbc.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import jdbc.command.Board01;

public class Member implements Member_inter {

	private String id;
	private String pw;
	private String name;
	private String email;
	private String address;
	private String grade;
	public int cnt;

	Scanner sc = new Scanner(System.in);

	public Member() {

	}


	public Member(String id, String pw, String name, String email, String address, String grade) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.address = address;
		this.grade = grade;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public void mInsert() {

		System.out.print("아이디>");
		String id = sc.next();

		System.out.print("비밀번호>");
		String pw = sc.next();

		System.out.print("이름>");
		String name = sc.next();

		System.out.print("이메일>");
		String email = sc.next();

		System.out.print("주소>");
		String address = sc.next();

		System.out.print("등급>");
		String grade = sc.next();

		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into members values(?,?,?,?,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, name);
			pstmt.setString(4, email);
			pstmt.setString(5, address);
			pstmt.setString(6, grade);

			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("DB입력 성공");
				mmInsert(grade,id);
			}else {
				System.out.println("아이디 중복");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		

	}

	@Override
	public void mUpdate() {

		System.out.print("수정할 아이디 입력>");
		String id = sc.next();

		System.out.print("수정할 이름 입력>");
		String name = sc.next();

		System.out.print("수정할 이메일 입력>");
		String email = sc.next();

		System.out.print("수정할 주소 입력>");
		String address = sc.next();

		//DB연동에 필요한 변수
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//pk는 수정 안함.
		String sql = "Update members set name =?, email =?, address =? where id = ?";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			pstmt.setString(3, address);
			pstmt.setString(4, id);

			int rs = pstmt.executeUpdate(); // 성공시 1반환

			if(rs == 1) {
				System.out.println(id+"회원 DB수정 성공");
			}else {
				System.out.println(id+"는 없는 회원입니다.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!= null) conn.close();
				if(pstmt!= null) pstmt.close();

			} catch (Exception e2) {

			}
		}

	}

	@Override
	public void mDelete() {

		System.out.print("삭제할 아이디 입력>");
		String id = sc.next();

		//DB 연결 변수 
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//sql문
		String sql = "delete from members where id = ?";

		//DB 연동		
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {			
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);

			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setString(1, id);			

			//전송결과 저장
			int rs = pstmt.executeUpdate();

			if(rs == 1) {
				System.out.println(id+"회원 정보 삭제 성공");
				mmDelet(id);
			} else {
				System.out.println(id+"회원 정보 삭제 실패");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e2) {

			}
		}
	}

	@Override
	public void lend() {


		System.out.print("회원id>");
		String id = sc.next();

		System.out.print("책이름>");
		String name = sc.next();

		System.out.print("빌린날짜>");
		String lend_date = sc.next();

		System.out.print("수량>");
		int count = sc.nextInt();


		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into lend values(SEQ_lend_lend_no.nextval,"
				+ "(select bno from Book where name = ? ) ,?,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, name);
			pstmt.setString(2, id);
			pstmt.setString(3, lend_date);

			pstmt.setInt(4, count);

			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("대여 DB입력 성공");
				
				//책 수량 업로드
				this.cnt =1;				
				//cnt(id,name);
				this.cnt = 0;
				//히스토리 업로드
				//his(id,name);
			}else {
				System.out.println("대여 DB입력 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}
		

	}

	@Override
	public void re() {

		System.out.print("아이디 입력");
		String id = sc.next();

		System.out.print("책이름>");
		String name = sc.next();

		System.out.print("반납날짜>");
		String re_date = sc.next();



		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into deadline values(SEQ_deadline_rno.nextval, \r\n" + 
				"                                    (select lend_no from lend where id = ?\r\n" + 
				"                                    and bno = (select bno from Book where name = ?) ),\r\n" + 
				"                                    (select bno from Book where name = ? ),?,null)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, name);
			pstmt.setString(4, re_date);

			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("반납 DB입력 성공");
				
				this.cnt =2;				
				//책수량 업로드
				//cnt(id,name);
				this.cnt =0;
				//연체료 계산
				int day = date(name,re_date);
				int count = count(id,name);
				arrears(day,count,name,id);
			}else {
				System.out.println("반납 DB입력 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		


	}

	@Override
	public Map<Member,List<Book>> mSearch() {		

		Member m = new Member();		
		List<Book> list = new ArrayList<>();
		Map<Member,List<Book>> map = new HashMap<>();		



		System.out.print("아이디>");
		String id = sc.next();

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="select \r\n" + 
				"        m.id,\r\n" + 
				"        m.name,\r\n" + 
				"        email,\r\n" + 
				"        address,\r\n" + 
				"        grade,\r\n" + 
				"        b.name as bname,\r\n" + 
				"        lend_count,\r\n" + 
				"        lend_date,\r\n" + 
				"        return_date,\r\n" + 
				"        arrears        \r\n" + 
				"from members m\r\n" + 
				"left outer join history h\r\n" + 
				"on m.id = h.id\r\n" + 
				"left outer join lend l\r\n" + 
				"on l.lend_no = h.lend_no\r\n" + 
				"left outer join book b\r\n" + 
				"on l.bno = b.bno\r\n" + 
				"left outer join deadline d\r\n" + 
				"on l.lend_no = d.lend_no\r\n" + 
				"where m.id = ?";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				//Member
				m.setId(rs.getString("id"));
				m.setName(rs.getString("name"));
				m.setEmail( rs.getString("email"));
				m.setAddress(rs.getString("address"));
				m.setGrade(rs.getString("grade"));

				//book
				Book b = new Book();
				b.setName(rs.getString("bname"));
				b.setCount(rs.getInt("lend_count"));
				b.setLend_date(rs.getString("lend_date"));
				b.setRe_date(rs.getString("return_date"));
				b.setPrice(rs.getInt("arrears"));

				list.add(b);
			}			
			map.put(m, list);			

		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}
		}
		return map;
	}

	@Override
	public Book bSearch() {

		Book b = new Book();

		System.out.print("책이름>");
		String name = sc.next();

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="select *from book where name =?";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);

			rs = pstmt.executeQuery();

			while(rs.next()) {

				//book
				StringBuffer num = new StringBuffer(""); 
				num.append(rs.getInt("bno"));
				num.append("-");
				num.append(rs.getInt("cno"));

				b.setBook_num(num.toString());
				b.setName(rs.getString("name"));
				b.setPrice(rs.getInt("price"));
				b.setWriter(rs.getString("writer"));
				b.setCount(rs.getInt("count"));
			}							
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}
		}			
		return b;
	}


	public void mmInsert(String grade, String id) { //manager 입력
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into manager values(?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, grade);
			pstmt.setString(2, id);

			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환

			if(result == 1) {
				System.out.println("등급 입력 성공");
			}else {
				System.out.println("아이디 중복");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}

	}

	public void mmDelet(String id) {

		//DB 연결 변수 
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		//sql문
		String sql = "delete from manager where id = ?";

		//DB 연동		
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {			
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);

			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);

			//?값 저장
			pstmt.setString(1, id);			

			//전송결과 저장
			int rs = pstmt.executeUpdate();

			if(rs == 1) {
				System.out.println(id+"회원 등급 삭제 성공");
			} else {
				System.out.println(id+"회원 등급 삭제 실패");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e2) {

			}
		}

	}


	public int date(String name, String re_date) {

		Book b= new Book();

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="select (to_date(?)-(lend_date+7)) as day from lend where bno = (select bno from Book where name = ? )";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, re_date);
			pstmt.setString(2, name);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				b.setDay(rs.getString("day"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}	
		}
		return Integer.parseInt(b.getDay());
	}


	public int count(String id,String name) {

		Book b= new Book();

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="select lend_count from lend where bno = (select bno from Book where name = ?) id = ?";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, id);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				b.setbCount(rs.getInt("lend_count"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}	
		}
		return b.getbCount();
	}

	public void arrears(int day,int count,String name,String id) {

		double pay;

		if(day<=0)
			pay = 0;
		else
			pay = day*count*500;

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		String sql ="update deadline set arrears = ? where bno  = (select bno from Book where name = ? )and lend_no in(select lend_no from lend where id=?)";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setDouble(1, pay);
			pstmt.setString(2, name);
			pstmt.setString(3, id);

			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("연체료 계산 성공");
			}else {
				System.out.println("연체료 등록 실패");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}	
		}
	}	


	public void his(String id, String name) {		

		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "insert into history values(SEQ_history_hno.nextval,\r\n" + 
				"                                (select lend_no \r\n" + 
				"                                from lend where bno = (select bno from Book where name = ? ) and id =  ?\r\n" + 
				"                                and lend_no <> (select lend_no from deadline where lend_no in (select lend_no \r\n" + 
				"                                from lend where bno  = (select bno from Book where name = ? ) \r\n" + 
				"                                and id =  ? ))) ,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, name);
			pstmt.setString(2, id);
			
			pstmt.setString(3, name);
			pstmt.setString(4, id);
			pstmt.setString(5, id);


			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("history DB입력 성공");
			}else {
				System.out.println("history DB입력 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();

			} catch (Exception e2) {

			}
		}		

	}

	public int bcnt(String name) {

		Book b= new Book();

		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="select count from book where bno = (select bno from Book where name = ?)";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				b.setbCount(rs.getInt("count"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}	
		}
		return b.getbCount();
	}

	public void cnt(String id,String name) {
		int lcnt = 0;
		
		if(this.cnt == 1)			 
			lcnt = bcnt(name) - count(id,name);
		else if(this.cnt == 2)
			lcnt = bcnt(name) + count(id,name);
		else lcnt =bcnt(name);
		
		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql ="update book set count = ? where bno  = (select bno from Book where name = ? )";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setDouble(1, lcnt);
			pstmt.setString(2, name);

			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환


			if(result == 1) {
				System.out.println("책 수량 계산 성공");
			}else {
				System.out.println("책 수량 계산 실패");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				//null이 아니라면 클로즈 				
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
				if(rs!=null) rs.close(); 				

			} catch (Exception e2) {

			}	
		}

	}

}



