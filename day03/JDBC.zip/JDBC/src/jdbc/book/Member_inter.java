package jdbc.book;

import java.util.List;
import java.util.Map;

public interface Member_inter {

	public void mInsert(); //member 클래스 정보
	public void mUpdate();  //member 클래스 정보
	public void mDelete(); //member 클래스 정보
	

	public Map<Member,List<Book>> mSearch(); //id pw name, List(book_info) (책 이름 빌린날짜 반납날짜[빌린날짜+7])
	public Book bSearch(); // 도서번호(책의 type no - 카테고리no), 책이름, 글쓴이, 가격, 책 수량, 상태
	
	public void lend(); //lend - (id book lend date)
	public void re(); //re - (id book lend date return date, arrears)
}
