package com.test.user.model;

import java.sql.Timestamp;

public class UserVO {

	private String id;
	private String pw;
	private String name;
	private String hp1;
	private String hp2;
	private String hp3;
	private String email_f;
	private String email_e;
	private String address_b;
	private String address_d;
	private Timestamp regdate; //시간타입
	
	
	//alt + shift + s
	public UserVO() {
		
	}

	
	

	public UserVO(String id, String pw, String name, String hp1, String hp2, String hp3, String email_f, String email_e,
			String address_b, String address_d, Timestamp regdate) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.hp1 = hp1;
		this.hp2 = hp2;
		this.hp3 = hp3;
		this.email_f = email_f;
		this.email_e = email_e;
		this.address_b = address_b;
		this.address_d = address_d;
		this.regdate = regdate;
	}




	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getPw() {
		return pw;
	}


	public void setPw(String pw) {
		this.pw = pw;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getHp1() {
		return hp1;
	}


	public void setHp1(String hp1) {
		this.hp1 = hp1;
	}


	public String getHp2() {
		return hp2;
	}


	public void setHp2(String hp2) {
		this.hp2 = hp2;
	}


	public String getHp3() {
		return hp3;
	}


	public void setHp3(String hp3) {
		this.hp3 = hp3;
	}


	public String getEmail_f() {
		return email_f;
	}


	public void setEmail_f(String email_f) {
		this.email_f = email_f;
	}


	public String getEmail_e() {
		return email_e;
	}


	public void setEmail_e(String email_e) {
		this.email_e = email_e;
	}


	public String getAddress_b() {
		return address_b;
	}


	public void setAddress_b(String address_b) {
		this.address_b = address_b;
	}


	public String getAddress_d() {
		return address_d;
	}


	public void setAddress_d(String address_d) {
		this.address_d = address_d;
	}


	public Timestamp getRegdate() {
		return regdate;
	}


	public void setRegdate(Timestamp regdate) {
		this.regdate = regdate;
	}
	
	
}
