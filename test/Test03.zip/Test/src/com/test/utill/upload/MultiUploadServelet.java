package com.test.utill.upload;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@MultipartConfig(
		location = "D:\\course\\jsp\\upload", //업로드할 경로
		maxFileSize = -1,					  //최대 파일 저장 크기
		maxRequestSize = -1,				  //요청에 대한 최대파일저장 크기
		fileSizeThreshold = 1024			  //임시저장하는 파일 크기 기본값
)
@WebServlet("/MultiUploadServelet")
public class MultiUploadServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public MultiUploadServelet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<String> list = new ArrayList<>();
		String realFileName = null;
		
		try {			
			
			Collection<Part> parts = request.getParts();
//			System.out.println(parts.toString());

			for(Part part: parts) { // 파일데이터가 담겨있는 객체를 찾는 작업
				System.out.println(part.getContentType());
				System.out.println(part.getName());
				if(part.getHeader("Content-Disposition").contains("filename=")) { //전달된 코드가 파일업로드 형식이라면

					realFileName = part.getSubmittedFileName(); //업로드된 파일명을 받는다
					System.out.println(part.getSize());
					if(part.getSize() > 0) { //파일이 있는 경우
						System.out.println(realFileName);
						part.write("D:\\course\\jsp\\upload\\" + realFileName); //헤딩 경로에 업로드시킨다
						part.delete(); //임시로 업로드한 파일을 제거해주어야함
					}
					list.add(realFileName);
				}
			}
			
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		System.out.println(list.toString());
		
		
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		try {
//			
//			conn = DriverManager.getConnection(url,uid,upw);
//			
//			for(String fileName:list) {
//				pstmt = conn.prepareStatement("insert into upload(id,filename) value(?,?)");
//				pstmt.setString(1, "kkk123");
//				pstmt.setString(1, fileName);
//				
//				pstmt.executeUpdate();
//			}
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		
	}

}
