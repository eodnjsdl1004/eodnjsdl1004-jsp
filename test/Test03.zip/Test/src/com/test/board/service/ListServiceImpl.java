package com.test.board.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.board.model.BoardDAO;
import com.test.board.model.BoardVO;
import com.test.util.Criteria;
import com.test.util.PageVO;

public class ListServiceImpl implements IBoardService{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDAO dao = BoardDAO.getInstance();

		Criteria cri = new Criteria(1,10);	

		//2번 페이지 부터 클릭했을 때 처리할 코드
		if( request.getParameter("pageNum") != null|request.getParameter("amount")!=null) {

			String pageNum = request.getParameter("pageNum");
			cri.setPageNum( Integer.parseInt(pageNum) );
			String amount = request.getParameter("amount");
			cri.setCount(Integer.parseInt(amount));
		}

		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		ArrayList<BoardVO> list = dao.getList(cri, id);		
		request.setAttribute("boardList", list);
		

		//화면에 보여질 페이지 버튼을 계산 처리
		//총게시글 수
		int total = dao.getTotal(id);
		PageVO vo = new PageVO(total, cri);

		request.setAttribute("pageVO", vo);
		
	}

}
