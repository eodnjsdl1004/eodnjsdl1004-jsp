package com.test.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.user.model.UserDAO;
import com.test.user.model.UserVO;



public class UserUpdateServiceImpl implements UserServiceImpl{

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");		
		String pw = request.getParameter("password");	
		String hp1 = request.getParameter("hp1");
		String hp2 = request.getParameter("hp2");
		String hp3 = request.getParameter("hp3");
		String name = request.getParameter("name");
		String email_f = request.getParameter("email_f");
		String email_e = request.getParameter("email_e");
		String address_b = request.getParameter("address_b");
		String address_d = request.getParameter("address_d");
		
		
		UserDAO dao = UserDAO.getInstance();
				
			UserVO vo = new UserVO(id, pw, name, hp1, hp2, hp3, email_f, email_e, address_b, address_d,null);
			
			int result = dao.update(vo);
			
			if(result == 1) { //비밀번호 및 회원정보 변경 성공
				HttpSession session = request.getSession();

				//아이디와 이름을 세션에 저장
				session.setAttribute("id", id);
				session.setAttribute("name", name);
				
				return result;				
			}else {	//비밀번호 및 회원정보 변경 실패
				return result;
			}
		
	}

}
