package com.test.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.user.model.UserDAO;
import com.test.user.model.UserVO;



public class UserJoinServiceImpl implements UserServiceImpl{

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {

		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		String name = request.getParameter("name");
		String hp1 = request.getParameter("hp1");
		String hp2 = request.getParameter("hp2");
		String hp3 = request.getParameter("hp3");		
		String email_f = request.getParameter("email_f");
		String email_e = request.getParameter("email_e");
		String address_b = request.getParameter("address_b");
		String address_d = request.getParameter("address_d");
		
		
		//DAO객체생성
		UserDAO dao = UserDAO.getInstance();	
		UserVO vo = new UserVO(id, pw, name, hp1, hp2, hp3, email_f, email_e, address_b, address_d,null);
		int result = dao.checkId(id);
		
		if(result ==1 ) { //아이디 이미 존재

			return result;
		} else {
		   int rs = dao.join(vo);
		   if(rs ==1) {
			   return 2;
		   } else {
			   return 0;
		   }
		}		
	}

}
