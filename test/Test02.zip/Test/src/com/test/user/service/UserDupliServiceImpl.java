package com.test.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.user.model.UserDAO;

public class UserDupliServiceImpl implements UserServiceImpl{

	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		String email_f = request.getParameter("email_f");
		String email_e = request.getParameter("email_e");
		
		UserDAO dao = UserDAO.getInstance();
		int result = dao.duplemail(id,email_f,email_e);
//		System.out.println(result);
		if(result==1) {//기존아이디의 이메일 값
			return 1;
		}else { // 기존아이디의 이메일 값이 아니라면
			int result2 =dao.dupl(email_f,email_e);
			
			if(result2==1) {//중복값임
				return 0;
			}else { //중복값이 아님
				return 2;
			}
			
		}
		
		
		
	}

}
