package com.test.user.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface UserServiceImpl {
	public int execute(HttpServletRequest request, HttpServletResponse response);
}
