package com.test.utill.upload;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

//파일 업로드시 MultiPartConfig 어노테이션  설정하거나 web.xml에 파일 업로드 내용을 선언해줍니다.

@MultipartConfig(
		location = "D:\\course\\jsp\\upload", //업로드할 경로
		maxFileSize = -1,					  //최대 파일 저장 크기
		maxRequestSize = -1,				  //요청에 대한 최대파일저장 크기
		fileSizeThreshold = 1024			  //임시저장하는 파일 크기 기본값
)
@WebServlet("/UploadServelet")
public class UploadServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public UploadServelet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//일반 폼값은 동일한 형식으로 받으면 됩니다.
		String writer = request.getParameter("name");
		String title = request.getParameter("title");

		//파일데이터는 request.getParts() 로 받습니다.
		
		try {			
		
		Collection<Part> parts = request.getParts();

		System.out.println(parts.toString());


		for(Part part: parts) { // 파일데이터가 담겨있는 객체를 찾는 작업
			System.out.println(part.getContentType());
			if(part.getHeader("Content-Disposition").contains("filename=")) { //전달된 코드가 파일업로드 형식이라면

				String realFileName = part.getSubmittedFileName(); //업로드된 파일명을 받는다

				if(part.getSize() > 0) { //파일이 있는 경우
					System.out.println(realFileName);
					part.write("D:\\course\\jsp\\upload\\" + realFileName); //헤딩 경로에 업로드시킨다
					part.delete(); //임시로 업로드한 파일을 제거해주어야함
				}
			}
		}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
