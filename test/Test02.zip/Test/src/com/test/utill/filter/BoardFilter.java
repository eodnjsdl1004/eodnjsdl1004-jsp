package com.test.utill.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


//Filter인터페이스를 상속받는다.
//@webfilter 어노테이션이나 web.xml에 필터 설정
//@WebFilter("*.board")
@WebFilter({"/bbs_writer.board", "/regist.board"}) //글쓰기 화면이나 글등록 화면에 대한 부분에서 세션검사를 함 
public class BoardFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		request.setCharacterEncoding("utf-8");	
		
		//HttpServletRequest은 매개변수로 들어오는 ServeletRequest의 자식이기 때문에 형변환을 함
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		
		HttpSession session = req.getSession();
		String id = (String)session.getAttribute("id");
		
		if(id==null) {
			res.setContentType("text/html; charset=UTF-8");
			PrintWriter out = res.getWriter();
			
			out.println("<script>");
			out.println("alert('권한이 없습니다.')");
			out.println("location.href='"+req.getContextPath()+"/main.do'");
			out.println("</script>");
			return;
		} 
		
		//세번째 매개변수인 FilterChain 클래스의 메서드인 doFilter()를 실행하여 서블릿이나, 다른 필터 클래스를 실행시킵니다.
		chain.doFilter(request, response);
		
	}

}
