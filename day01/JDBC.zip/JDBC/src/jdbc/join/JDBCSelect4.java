package jdbc.join;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import jdbc.command.Board01;
import jdbc.command.MemberBoard01;

public class JDBCSelect4 {

	public static void main(String[] args) {
		//조인에 대한 처리
		
		List<Board01> list = new ArrayList<>();
		MemberBoard01 mb = new MemberBoard01(); //1대 N에 대한 관계 aaa
//		MemberBoard01 mb2 = new MemberBoard01(); //1대 N에 대한 관계 bbb
//		List<MemberBoard01> l = new ArrayList<>();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("아이디>");
		String id = sc.next();
		
		//DB연결 변수		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		String sql ="select  \r\n" + 
				"        m.id,\r\n" + 
				"        m.pw,\r\n" + 
				"        m.name,\r\n" + 
				"        m.email,\r\n" + 
				"        m.address,\r\n" + 
				"        b.bno,\r\n" + 
				"        b.title,\r\n" + 
				"        b.content        \r\n" + 
				"from member01 m\r\n" + 
				"join (select  rn,\r\n" + 
				"                 bno,\r\n" + 
				"                 id,                 \r\n" + 
				"                 title,\r\n" + 
				"                 content\r\n" + 
				"      from (select \r\n" + 
				"                        rownum rn,\r\n" + 
				"                        bno,\r\n" + 
				"                        id, \r\n" + 
				"                        title,\r\n" + 
				"                        content\r\n" + 
				"              from (select\r\n" + 
				"                                *\r\n" + 
				"                        from board01 \r\n" + 
				"                        order by bno desc))\r\n" + 
				"     where rn >=10 and rn<=20) b\r\n" + 
				"on m.id = b.id\r\n" + 
				"where m.id = ?";
		//DB연동 변수
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				//Member01
				String id2 = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				//Board01
				int bno = rs.getInt("bno");
				String title = rs.getString("title");
				String content = rs.getString("content");
				
				mb.setId(id2);
				mb.setPw(pw);
				mb.setName(name);
				mb.setEmail(email);
				mb.setAddress(address);
				
				Board01 board = new Board01();
				board.setBno(bno);
				board.setTitle(title);
				board.setContent(content);				
				list.add(board);
				
			}
			mb.setList(list);
//			l.add(mb);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			sc.close();
 			try {
 				//null이 아니라면 클로즈 				
 				if(conn!=null) conn.close();
 				if(pstmt!=null) pstmt.close();
 				if(rs!=null) rs.close(); 				
 				
			} catch (Exception e2) {

			}
 		}
		
		System.out.println(mb.getId()+" " +mb.getPw()+" "+mb.getName()+" "+mb.getEmail() +" "+mb.getAddress());
		mb.getList().forEach((b)-> System.out.println(b.getBno()+" "+b.getTitle()+" "+b.getContent()));
				
	}
}
