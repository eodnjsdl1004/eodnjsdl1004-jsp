package jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class JDBCDelete {

	public static void main(String[] args) {
		
		//지원 아이디를 받아서 해당 아이디를 삭제하는 JDBC 코드를 완성.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("삭제할 아이디 입력>");
		String id = sc.next();
		
		//DB 연결 변수 
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		//sql문
		String sql = "delete from member01 where id = ?";
		
		//DB 연동		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {			
			//드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//연결 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			
			//전송 객체 생성
			pstmt = conn.prepareStatement(sql);
			
			//?값 저장
			pstmt.setString(1, id);			
			
			//전송결과 저장
			int rs = pstmt.executeUpdate();
			
			if(rs == 1) {
				System.out.println(id+"회원 정보 삭제 성공");
			} else {
				System.out.println(id+"회원 정보 삭제 실패");
			}			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
			try {
				if(conn!=null) conn.close();
				if(pstmt!=null) pstmt.close();
			} catch (Exception e2) {

			}
		}
		
	}
}

