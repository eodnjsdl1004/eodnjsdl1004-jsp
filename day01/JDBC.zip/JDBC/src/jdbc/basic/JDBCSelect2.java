package jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class JDBCSelect2 {

	public static void main(String[] args) {

		/*
		 * 회원 ID를 입력받아서 해당 ID의 회원정보를 모두 출력하는 JDBC코드를 작성. 
		 */

		Scanner sc = new Scanner(System.in);

		System.out.print("아이디 입력>");
		String id = sc.next();


		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";

		String sql = "select * from member01 where id = ?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {			
			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(url,uid,upw);

			System.out.println(conn);
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();


			if(rs.next()) {

				String id2 = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String address = rs.getString("address");
				
				System.out.println(id2+" "+pw+" "+name+" "+email+" "+address);				
				
			}else { // 조회한 id가 없는 경우
				System.out.println(id+"는 없습니다.");
			}

			} catch (Exception e) {
				e.printStackTrace();
				
			} finally {
				
				sc.close();				
				try {
					if(conn!=null) conn.close();
					if(pstmt!=null) pstmt.close();
					if(rs!=null) rs.close();
				} catch (Exception e2) {
					
				}
			}

		}
	}
