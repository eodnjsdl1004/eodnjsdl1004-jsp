package jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class JDBC_Insert {
	public static void main(String[] args) {
		
		
		//스캐너 생성
		Scanner sc= new Scanner(System.in);
		
		System.out.print("아이디>");
		String id = sc.next();
		
		System.out.print("비밀번호>");
		String pw = sc.next();
		
		System.out.print("이름>");
		String name = sc.next();
		
		System.out.print("이메일>");
		String email = sc.next();
		
		System.out.print("주소>");
		String address = sc.next();
		
		//DB연결에 필요한 변수 	
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		String sql = "insert into member01 values(?,?,?,?,?)";
		
		//DB연동에 필요한 변수 	
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			//JDBC 연결 드라이버 호출
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//커넥션 객체 생성
			conn = DriverManager.getConnection(url,uid,upw);
			//sql문 전송을 위한 pstmt 객체 생성
			//sql문의 ?의 순서대로 인덱스번호를 가지고 1부터 시작합니다. pstmt에 전달된 sql문의 ?를 채우는 작업.
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, name);
			pstmt.setString(4, email);
			pstmt.setString(5, address);
			
			//sql문의 실행 (insert, delete, update)문은 executeUpdate()문을 실행
			int result = pstmt.executeUpdate(); // 인서트 성공시 1을 반환, 실패하면 0을 반환
			
			
			if(result == 1) {
				System.out.println("DB입력 성공");
			}else {
				System.out.println("DB입력 실패");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
			try {
				if(conn!=null) conn.close(); //연결성공시 값이 있으므로 닫음
				if(pstmt!=null) pstmt.close();
				
			} catch (Exception e2) {
				
			}
		}
		
		
		
	}

}
