package jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jdbc.command.Member01;

public class JDBC_Select {

	public static void main(String[] args) {		
		//JDBC셀렉트 
		//DB주소, DB_ID, DB_PW
		
		/*create table member01(

			    id varchar(30) not null,
			    pw varchar(30),
			    name varchar(30),
			    email varchar(30),
			    address varchar(50)
			);
			
			alter table member01 add constraint member01_pk primary key (id);
			
			insert into member01 values('kkk123','1234', '홍길동','kkk123@naver.com','서울시');
			insert into member01 values('aaa123','1234', '홍길순','aaa123@naver.com','경기도');
			insert into member01 values('bbb123','1234', '이순신','bbb123@naver.com','부산시');
		 */
		
		List<Member01> list = new ArrayList<>();
		
		String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
		String uid = "JSP";
		String upw = "jsp";
		
		//SQL문 String변수에 저장
		String sql = "select*from member01 order by id desc";
		
		//DB연동에 사용할 클래스 변수들을 미리 try 밖에 선언
		Connection conn = null; //DB연결
		PreparedStatement pstmt = null; //SQL 전송객체
		ResultSet rs = null; //쿼리결과 저장객체
		
		
		/*
		 * java.sql패키지에 클래스들을 사용하려면, 반드시 try~catch 블록안에서 사용
		 * 그 이유는 해당 메서드들이 모두 예외 던지기 throws 처리가 되어있기 때문입니다.
		 */
 		try {
			// connector 안에 연결 드라이버를 호출
 			Class.forName("oracle.jdbc.driver.OracleDriver");
 			
 			// 커넥션 객체 생성
 			//커넥션객체 생성시에는 직접 new로 사용할 수 없고, 
 			//DriverManager 클래스가 제공하는 getter메서드를 통해서 생성
 			conn = DriverManager.getConnection(url,uid,upw);
 			
 			System.out.println(conn);
 			
 			//SQL 쿼리문을 실행해주는 statement 객체를 생성
 			pstmt = conn.prepareStatement(sql);
 			
 			//sql문 실행 - select문 - executeQuery(), 인서트, 딜리트, 업데이트 executeUpate()
 			rs = pstmt.executeQuery();
 			
 			//select 구문의 결과로 데이터가 존재하면 next()메서드는 true를 반환
 			//select 구문의 실행결과를 하나씩 처리할때, rs.getString(컬럼명) rs.getInt(컬럼명) rs.getTimeStamp(컬럼명)으로 사용
 			while(rs.next()) {
 				
 				String id = rs.getString("id");
 				String pw = rs.getString("pw");
 				String name = rs.getString("name");
 				String email = rs.getString("email");
 				String address = rs.getString("address");
 				
 				System.out.println(id+" "+pw+" "+name+" "+email+" "+address);
 				Member01 member = new Member01(id,pw,name,email,address);
 				
 				list.add(member);
 			}
 			//System.out.println(list.toString());
 			
		} catch (Exception e) {
			e.printStackTrace(); //에러로그
		}
 		
 		finally {
 			try {
 				//null이 아니라면 클로즈 				
 				if(conn!=null) conn.close();
 				if(pstmt!=null) pstmt.close();
 				if(rs!=null) rs.close(); 				
 				
			} catch (Exception e2) {

			}
 		}
 		
	}
}
